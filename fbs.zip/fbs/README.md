<h1 align="center">FBS v1.0</h1>
<p align="center">
      A new facebook account cracker tool for termux users
</p>

## ***About FBS***:

FBS is a python based script. You can use this tool for crack facebook users passwords. This tool works on both rooted Android device and Non-rooted Android device.

## All commands for install this tool
$ pkg update && pkg upgrade
<br>
$ pkg install python
<br/>
$ pkg install python2
<br/>
$ pkg install git
<br/>
$ pkg install wget
<br/>
$ pkg install php
<br/>
$ pkg install openssh
<br/>
$ git clone https://github.com/rxbltd/fbs
<br/>
$ pip2 install requests
<br/>
$ pip2 install mechanize
<br/>
$ ls
<br/>
$ cd fbs
<br/>
$ python2 fbs.py
<br/>
...
<br/>
• TOOL USER : (knock me on facebook)
<br/>
• TOOL PASS : (knock me on facebook)
<br/>
....
<br/>

* Note:- Don't try to edit or modify this tool.

## ***Check this***

### Chekout our webite:
https://www.tipstunebd.com

## ***Join***

### Telegram channel:
https://t.me/mrbsoft

### Facebook page:
https://www.facebook.com/mrbsoftltd


### My GitHub ID link:
https://www.github.com/rxbltd

### Warning

***This tool is only for educational purpose. If you use this tool for other purposes except education we will not be responsible in such cases.***
